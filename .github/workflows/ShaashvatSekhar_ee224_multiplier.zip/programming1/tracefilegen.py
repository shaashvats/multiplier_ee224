def bitwise_multiply(a, b):
    # Convert the numbers to 4-bit binary strings
    bin_a = format(a, '04b')
    bin_b = format(b, '04b')
    
    # Perform multiplication
    product = a * b
    
    # Calculate the maximum bit length of the product to display
    # For a 4-bit unsigned int, the product can be up to 8 bits.
    bin_product = format(product, '08b')

    return(f"{bin_a}{bin_b} {bin_product} 1")

def append_to_file(filename, lines):
    with open(filename, 'a') as file:
        file.write(str(lines + '\n'))


# Example usage
for i in range(16):
    for j in range(16):
        append_to_file("TRACEFILE.txt", bitwise_multiply(i, j))
        

